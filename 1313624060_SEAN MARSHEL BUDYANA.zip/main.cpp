#include <iostream>
using namespace std;

int main() {
    // Your code goes here
    
    return 0;
}
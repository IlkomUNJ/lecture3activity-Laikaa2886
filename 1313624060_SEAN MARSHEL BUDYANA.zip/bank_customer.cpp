#include "bank_customer.h"

BankCustomer::BankCustomer() {
    name = "";
    accountNumber = "";
    balance = 0.0;
}

BankCustomer::BankCustomer(string n, string accNum, double bal) {
    name = n;
    accountNumber = accNum;
    balance = bal;
}

void BankCustomer::setName(string n) {
    name = n;
}

void BankCustomer::setAccountNumber(string accNum) {
    accountNumber = accNum;
}

void BankCustomer::setBalance(double bal) {
    balance = bal;
}

string BankCustomer::getName() const {
    return name;
}

string BankCustomer::getAccountNumber() const {
    return accountNumber;
}

double BankCustomer::getBalance() const {
    return balance;
}

void BankCustomer::deposit(double amount) {
    if (amount > 0) {
        balance += amount;
    }
}

void BankCustomer::withdraw(double amount) {
    if (amount > 0 && amount <= balance) {
        balance -= amount;
    }
}

void BankCustomer::displayInfo() const {
    cout << "Customer Name" << name << endl 
    cout << "Account Number: " << accountnumber << endl
    cout << "Balance : $" << balance << endl
}
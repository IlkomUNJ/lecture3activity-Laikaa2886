#ifndef SELLER_H
#define SELLER_H

#include <string>
#include <vector>
#include "item.h"

using namespace std;

class Seller {
private:
    int id;
    string name;
    string address;
    string phoneNumber;
    vector<Item> items;

public:
    // Constructors
    Seller() {
        this->id = 0;
        this->name = "";
        this->address = "";
        this->phoneNumber = "";
    }

    Seller(int id, string name, string address, string phoneNumber) {
        this->id = id;
        this->name = name;
        this->address = address;
        this->phoneNumber = phoneNumber;
    }

    // Getters
    int getId() { return this->id; }
    string getName() { return this->name; }
    string getAddress() { return this->address; }
    string getPhoneNumber() { return this->phoneNumber; }
    vector<Item>& getItems() { return this->items; }

    // Setters
    void setId(int id) { this->id = id; }
    void setName(string name) { this->name = name; }
    void setAddress(string address) { this->address = address; }
    void setPhoneNumber(string phoneNumber) { this->phoneNumber = phoneNumber; }

    // Item management methods
    void addItem(Item item) {
        items.push_back(item);
    }

    bool removeItem(int itemId) {
        for (auto it = items.begin(); it != items.end(); ++it) {
            if (it->getId() == itemId) {
                items.erase(it);
                return true;
            }
        }
        return false;
    }

    // Update item methods that utilize Item class's update methods
    bool updateItemPrice(int itemId, double newPrice) {
        for (auto& item : items) {
            if (item.updatePrice(itemId, newPrice)) {
                return true;
            }
        }
        return false;
    }

    bool updateItemQuantity(int itemId, int newQuantity) {
        for (auto& item : items) {
            if (item.updateQuantity(itemId, newQuantity)) {
                return true;
            }
        }
        return false;
    }

    bool updateItemName(int itemId, string newName) {
        for (auto& item : items) {
            if (item.updateName(itemId, newName)) {
                return true;
            }
        }
        return false;
    }

    bool updateItemAll(int itemId, string newName, double newPrice, int newQuantity) {
        for (auto& item : items) {
            if (item.updateAll(itemId, newName, newPrice, newQuantity)) {
                return true;
            }
        }
        return false;
    }
};

#endif
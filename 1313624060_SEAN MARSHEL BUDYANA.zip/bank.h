#ifndef BANK_H
#define BANK_H

#include <string>
#include <vector>
#include <map>
#include "bank_customer.h"

using namespace std;

class Bank {
private:
    int id;
    string name;
    string address;
    string phoneNumber;
    map<string, BankCustomer> customers;  // Map of account number to customer

public:
    // Constructors
    Bank() {
        this->id = 0;
        this->name = "";
        this->address = "";
        this->phoneNumber = "";
    }

    Bank(int id, string name, string address, string phoneNumber) {
        this->id = id;
        this->name = name;
        this->address = address;
        this->phoneNumber = phoneNumber;
    }

    // Getters
    int getId() { return this->id; }
    string getName() { return this->name; }
    string getAddress() { return this->address; }
    string getPhoneNumber() { return this->phoneNumber; }

    // Setters
    void setId(int id) { this->id = id; }
    void setName(string name) { this->name = name; }
    void setAddress(string address) { this->address = address; }
    void setPhoneNumber(string phoneNumber) { this->phoneNumber = phoneNumber; }

    // Customer management methods
    bool addCustomer(BankCustomer customer) {
        string accountNumber = customer.getAccountNumber();
        if (customers.find(accountNumber) == customers.end()) {
            customers[accountNumber] = customer;
            return true;
        }
        return false;
    }

    bool removeCustomer(string accountNumber) {
        if (customers.find(accountNumber) != customers.end()) {
            customers.erase(accountNumber);
            return true;
        }
        return false;
    }

    BankCustomer* findCustomer(string accountNumber) {
        if (customers.find(accountNumber) != customers.end()) {
            return &customers[accountNumber];
        }
        return nullptr;
    }

    // Transaction methods
    bool deposit(string accountNumber, double amount) {
        BankCustomer* customer = findCustomer(accountNumber);
        if (customer != nullptr && amount > 0) {
            customer->setBalance(customer->getBalance() + amount);
            return true;
        }
        return false;
    }

    bool withdraw(string accountNumber, double amount) {
        BankCustomer* customer = findCustomer(accountNumber);
        if (customer != nullptr && amount > 0 && customer->getBalance() >= amount) {
            customer->setBalance(customer->getBalance() - amount);
            return true;
        }
        return false;
    }

    bool transfer(string fromAccount, string toAccount, double amount) {
        BankCustomer* sender = findCustomer(fromAccount);
        BankCustomer* receiver = findCustomer(toAccount);

        if (sender != nullptr && receiver != nullptr && 
            amount > 0 && sender->getBalance() >= amount) {
            
            sender->setBalance(sender->getBalance() - amount);
            receiver->setBalance(receiver->getBalance() + amount);
            return true;
        }
        return false;
    }

    // Utility methods
    vector<BankCustomer> getAllCustomers() {
        vector<BankCustomer> customerList;
        for (const auto& pair : customers) {
            customerList.push_back(pair.second);
        }
        return customerList;
    }

    double getTotalBankDeposits() {
        double total = 0.0;
        for (const auto& pair : customers) {
            total += pair.second.getBalance();
        }
        return total;
    }
};

#endif
#ifndef BANK_CUSTOMER_H
#define BANK_CUSTOMER_H

#include <string>

class BankCustomer {
private:
    int id;
    std::string name;
    double balance;

public:
    // Constructors
    BankCustomer();
    BankCustomer(int id, std::string name, double balance);

    // Getters
    int getId() const;
    std::string getName() const;
    double getBalance() const;

    // Setters
    void setId(int id);
    void setName(std::string name);
    void setBalance(double balance);

void 
};

#endif
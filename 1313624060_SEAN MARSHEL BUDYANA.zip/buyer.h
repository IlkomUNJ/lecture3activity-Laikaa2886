#ifndef BUYER_H
#define BUYER_H

#include <string>
#include "bank_customer.h"

using namespace std;

class Buyer {
private:
    int id;
    string name;

public:
    // Constructors
    Buyer() {
        this->id = 0;
        this->name = "";
    }

    Buyer(int id, string name) {
        this->id = id;
        this->name = name;
    }

    // Getters and Setters
    int getId() {
        return this->id;
    }

    void setId(int id) {
        this->id = id;
    }

    string getName() {
        return this->name;
    }

    void setName(string name) {
        this->name = name;
    }
};

#endif
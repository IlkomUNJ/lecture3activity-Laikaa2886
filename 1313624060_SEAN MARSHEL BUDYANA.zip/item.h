#ifndef ITEM_H
#define ITEM_H

#include <string>
using namespace std;

class Item {
private:
    int id;
    string name;
    double price;
    int quantity;

public:
    // Constructors
    Item() {
        this->id = 0;
        this->name = "";
        this->price = 0.0;
        this->quantity = 0;
    }

    Item(int id, string name, double price, int quantity) {
        this->id = id;
        this->name = name;
        this->price = price;
        this->quantity = quantity;
    }

    // Getters
    int getId() { return this->id; }
    string getName() { return this->name; }
    double getPrice() { return this->price; }
    int getQuantity() { return this->quantity; }

    // Setters
    void setId(int id) { this->id = id; }
    void setName(string name) { this->name = name; }
    void setPrice(double price) { this->price = price; }
    void setQuantity(int quantity) { this->quantity = quantity; }

    // Special methods to change item properties based on ID
    bool updatePrice(int itemId, double newPrice) {
        if (this->id == itemId) {
            this->price = newPrice;
            return true;
        }
        return false;
    }

    bool updateQuantity(int itemId, int newQuantity) {
        if (this->id == itemId) {
            this->quantity = newQuantity;
            return true;
        }
        return false;
    }

    bool updateName(int itemId, string newName) {
        if (this->id == itemId) {
            this->name = newName;
            return true;
        }
        return false;
    }

    bool updateAll(int itemId, string newName, double newPrice, int newQuantity) {
        if (this->id == itemId) {
            this->name = newName;
            this->price = newPrice;
            this->quantity = newQuantity;
            return true;
        }
        return false;
    }
};

#endif